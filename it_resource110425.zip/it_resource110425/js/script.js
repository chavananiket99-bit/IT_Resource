var tooltipTriggerList = [].slice.call(
  document.querySelectorAll('[data-bs-toggle="tooltip"]')
);
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl);
});

const toast = document.querySelector("#toast");
const toastTimer = document.querySelector("#timer");
const closeToastBtn = document.querySelector("#toast-close");
const toastTitle = document.querySelector("#toast-message h4");
const toastMessage = document.querySelector("#toast-message p");
const toastIcon = document.querySelector("#icon");
let countdown;

const closeToast = () => {
  toast.style.animation = "close 0.3s cubic-bezier(.87,-1,.57,.97) forwards";
  toastTimer.classList.remove("timer-animation");
  clearTimeout(countdown);
};

const openToast = (type, title, message, iconClass) => {
  toast.classList = [type];
  toastTitle.textContent = title;
  toastMessage.textContent = message;
  toastIcon.className = `bi ${iconClass}`;
  toast.style.animation = "open 0.3s cubic-bezier(.47,.02,.44,2) forwards";
  toastTimer.classList.add("timer-animation");
  clearTimeout(countdown);
  countdown = setTimeout(() => {
    closeToast();
  }, 5000);
};

closeToastBtn.addEventListener("click", closeToast);

//sidebar toggle
$(".burgermenu").click(function () {
  $(".main_body").toggleClass("toggle-sidebar");
});

opened = false;
window.onload = function () {
  var btn = document.getElementsByClassName("burgermenu")[0];
  btn.addEventListener("click", onBtnClick);
};

function onBtnClick(e) {
  this.classList.toggle("opened");
}

$(function () {
  var today = new Date();

  $("#startDate").datepicker({
    dateFormat: "dd-mm-yy",
    minDate: today,
    onSelect: function (selectedDate) {
      var startDate = $(this).datepicker("getDate");
      $("#endDate").datepicker("option", "minDate", startDate);
    },
  });

  $("#endDate").datepicker({
    dateFormat: "dd-mm-yy",
    minDate: today,
  });

  $("#startProjectDate").datepicker({
    dateFormat: "dd-mm-yy",
    minDate: today,
    onSelect: function (selectedDate) {
      const start = new Date(selectedDate);
      const minEndDate = new Date(start);
      minEndDate.setFullYear(start.getFullYear() + 1);

      $("#endProjectDate").datepicker("option", "minDate", minEndDate);
    },
  });

  $("#endProjectDate").datepicker({
    dateFormat: "dd-mm-yy",
    minDate: today,
  });
});

$(document).ready(function () {
  //Datatable
  var table = $("#example").DataTable({
    scrollY: "200px",
    scrollCollapse: true,
    paging: true,
    autoWidth: true,
    ordering: false,
    initComplete: function () {
      var api = this.api();
      setTimeout(function () {
        api.columns.adjust().draw();
      }, 300);
    },
  });

  setTimeout(function () {
    table.columns.adjust().draw();
  }, 500);
});

//mobile responsive way data show
const data = [
  {
    requestid: "MM79451",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79450",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79450",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79450",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79450",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79450",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79450",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79450",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79450",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79450",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79451",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79450",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79451",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79450",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79451",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79450",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79451",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79450",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79451",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79450",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79451",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79450",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79451",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79450",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79451",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79450",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
  {
    requestid: "MM79451",
    module: "Administration",
    band: "1-2 Years",
    citmanager: "CIT Manager",
  },
];

let currentPage = 1;
const entriesPerPage = 10;

function displayData(filteredData) {
  const start = (currentPage - 1) * entriesPerPage;
  const end = start + entriesPerPage;
  const paginatedData = filteredData.slice(start, end);

  // Desktop Table View
  document.getElementById("tableBody").innerHTML = paginatedData
    .map(
      (item, index) => `
   <tr>
   <td>${item.requestid}</td>
   <td>${item.module}</td>
   <td>${item.band}</td>
   <td>${item.citmanager}</td>
   <td class="text-center">
   <button class="btn" onclick="editRow(${start + index})">
    <a href="#" class="">
      <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      fill="#e31837"
      class="bi bi-pencil"
      viewBox="0 0 16 16"
      >
      <path
       d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325"
      /></svg
    ></a>
   </button>
   </td>
   </tr>
              `
    )
    .join("");

  // Mobile Div View
  document.getElementById("mobileView").innerHTML = paginatedData
    .map(
      (item, index) => `
  <div class="border p-2 mb-2 bg-light rounded">
  <div class="d-flex justify-content-between align-items-center">
  <button class="btn btn-link mobile-location-btn w-100 text-start" onclick="toggleDetails(${
    start + index
  })"><strong>Request ID:</strong> ${item.requestid}</button>
  <button class="btn" onclick="editRow(${start + index})">
    <a href="#" class="">
      <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      fill="#e31837"
      class="bi bi-pencil"
      viewBox="0 0 16 16"
      >
      <path
      d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325"
      /></svg
    ></a>
  </button>
  </div>
  <div id="details-${start + index}" class="collapse mt-2 ps-2">
  <p><strong>Department:</strong> ${item.module}</p>
  <p><strong>Date:</strong> ${item.band}</p>
  <p><strong>Severity:</strong> ${item.citmanager}</p>
  </div>
  </div>
             `
    )
    .join("");

  document.getElementById(
    "pageInfo"
  ).innerText = `Page ${currentPage} of ${Math.ceil(
    filteredData.length / entriesPerPage
  )}`;
}
function toggleDetails(index) {
  const detailsDiv = document.getElementById(`details-${index}`);
  const bsCollapse = new bootstrap.Collapse(detailsDiv);
  bsCollapse.toggle();
}
function updatePagination(filteredData) {
  document.getElementById("prevPage").disabled = currentPage === 1;
  document.getElementById("nextPage").disabled =
    currentPage * entriesPerPage >= filteredData.length;
}
function applySearch(page = 1) {
  const query = document.getElementById("search").value.toLowerCase();
  const filteredData = data.filter((item) =>
    Object.values(item).some((value) =>
      value.toString().toLowerCase().includes(query)
    )
  );
  currentPage = page;
  displayData(filteredData);
  updatePagination(filteredData);
}
document
  .getElementById("search")
  .addEventListener("input", () => applySearch(1));

document.getElementById("prevPage").addEventListener("click", () => {
  if (currentPage > 1) {
    currentPage--;
    applySearch(currentPage);
  }
});
document.getElementById("nextPage").addEventListener("click", () => {
  currentPage++;
  applySearch(currentPage);
});
// Initialize with first page
applySearch();
